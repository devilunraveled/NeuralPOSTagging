# NeuralPOSTagging

If you want to understand the code :

- config.py 
- dataHandler.py 
- model.py
- ffnn.py
- rnn.py

The learningRate is defined in the files for the models themselves. It is definetely not my best coding work :/ 

To download the checkpoints, visit this link : []

[OneDrive Link Top Model Checkpoints](https://iiitaphyd-my.sharepoint.com/:f:/g/personal/hardik_sharma_students_iiit_ac_in/EglTeRTigcBEmZxkfjeVzfYBuuubmBIPkkX8eKGo9AC9Yg?e=tko9ev)

