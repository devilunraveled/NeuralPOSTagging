# Done to make my life easier, creating the parent
# folder as a package allows me to access the functions
# from this folder directly from the parent files.

import sys
sys.path.append("..")
